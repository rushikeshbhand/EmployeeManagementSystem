package com.projectems.dto;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DemoDTO {

	private String demoUsername;
	private String demoPassword;
	
}
